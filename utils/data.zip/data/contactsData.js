export const contactsData = {
    email: 'huzaifaquadri1853@gmail.com',
    phone: '+91-9179368253',
    address: 'Indore, Madhya Pradesh, India',
    github: 'https://github.com/Huzaifa-Quadri',
    facebook: '#',
    linkedIn: 'www.linkedin.com/in/huzaifa-quadri-271a31250',
    twitter: '#',
    stackOverflow: 'https://stackoverflow.com/users/25985984/crazyflutterdev',
    devUsername: "huzaifa-quadri"
}