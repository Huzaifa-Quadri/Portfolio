export const educations = [
  {
    id: 1,
    title: "Bachelor Degree",
    duration: "2021 - Present",
    institution: "Medicaps University, Indore",
  },
  {
    id: 2,
    title: "Higher Secondary Certificate",
    duration: "2020 - 2021",
    institution: "A.B.N Higher Secondary School",
  },
  {
    id: 3,
    title: "Secondary School Certificate",
    duration: "2018 - 2019",
    institution: "A.B.N Higher Secondary School",
  }
]