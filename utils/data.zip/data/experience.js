export const experiences = [
  {
    id: 1,
    title: "Self Employed",
    company: "Code and build something in everyday.",
    duration: "(Jan 2024 - Present)"
  }
]